//
//  RztimeAppDelegate.h
//  RzChinaXiangqi
//
//  Created by 6407 on 15-7-17.
//  Copyright (c) 2015年 Rztime. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RztimeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
