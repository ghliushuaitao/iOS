//
//  RztimeViewController.m
//  RzChinaXiangqi
//
//  Created by 6407 on 15-7-17.
//  Copyright (c) 2015年 Rztime. All rights reserved.
//

#import "RztimeViewController.h"

@interface RztimeViewController ()
{
    // 当前点击的棋子
    UIButton *btnClickChess;
    
    // 计时
    UILabel *lbTime;
    // 用于计时
    NSTimer *timer;
    
    NSTimer *_timer;
    // 时分秒
    int hour;
    int min;
    int s;
    
    // 设置先后手   // 红棋为 1， 黑棋为 2
    int WhoCanGo;
    
    // 提示当前谁走
    UILabel *lbWhoCango;
    
    // 记录 将 或者 帅的位置，用于判断是否将军
    int JiangLocate;
    int ShuaiLocate;
    
    // 提示 将军了
    UILabel *lbJiangJun;
    
    // 重新开始
    UIButton *btnStart;
}

@end

@implementation RztimeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor brownColor];
    
    btnClickChess = NULL;
    
    // 初始化棋盘
    [self InitQipan];
    
    // 初始化棋子
    [self InitChess];
    
    // 设置时间,谁走，将军提示
    [self SetTimerLabel];
    
    // 首先设置红棋先走
    WhoCanGo = 1;
    // 初始 将 帅的坐标
    JiangLocate = 15;
    ShuaiLocate = 105;
}

// 设置时间
-(void)SetTimerLabel
{
    // 计时
    lbTime = [[UILabel alloc]initWithFrame:CGRectMake(30, 400, 200, 30)];
    lbTime.text = @"00 : 00 : 00";
    hour = min = s = 0;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(SetTime) userInfo:nil repeats:YES];
    [self.view addSubview:lbTime];
    
    // 提示当前谁出手
    lbWhoCango = [[UILabel alloc]initWithFrame:CGRectMake(30, 350, 200, 30)];
    lbWhoCango.text = @"红棋 出手";
    [self.view addSubview:lbWhoCango];
    
    lbJiangJun = [[UILabel alloc]initWithFrame:CGRectMake(170, 330, 120, 120)];
    lbJiangJun.layer.cornerRadius = 60.0;
    lbJiangJun.layer.masksToBounds = YES;
    lbJiangJun.text = @"将军";
    lbJiangJun.textColor = [UIColor whiteColor];
    lbJiangJun.textAlignment = NSTextAlignmentCenter;
    lbJiangJun.backgroundColor = [UIColor grayColor];
    lbJiangJun.hidden = YES;
    [self.view addSubview:lbJiangJun];
    
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(JudgeWillKillBoss) userInfo:nil repeats:YES];
}

// 计时
-(void)SetTime
{
    ++s;
    if (s >= 60) {
        min++;
        s = 0;
    }
    if (min >= 60) {
        hour++;
        min = 0;
    }
    lbTime.text = [NSString stringWithFormat:@"%02d : %02d : %02d", hour, min, s];
}

// 初始化棋盘
-(void)InitQipan
{
    // 初始化界面
    // 横向方框
    for (int i = 0; i < 10; i++) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(30, 30+i*30, 240, 2)];
        label.layer.borderColor = [UIColor blackColor].CGColor;
        label.layer.borderWidth = 1;
        
        [self.view addSubview:label];
    }
    // 纵向
    for (int i = 0; i < 9; i++) {
        UILabel *label_1 = [[UILabel alloc]initWithFrame:CGRectMake(30 + i*30, 30, 2, 120)];
        label_1.layer.borderColor = [UIColor blackColor].CGColor;
        label_1.layer.borderWidth = 1;
        
        UILabel *label_2 = [[UILabel alloc]initWithFrame:CGRectMake(30 + i*30, 180, 2, 120)];
        label_2.layer.borderColor = [UIColor blackColor].CGColor;
        label_2.layer.borderWidth = 1;
        
        [self.view addSubview:label_1];
        [self.view addSubview:label_2];
    }
    // 楚汉 河界 左右边框
    UILabel *label_3 = [[UILabel alloc]initWithFrame:CGRectMake(30, 150, 2, 30)];
    label_3.layer.borderColor = [UIColor blackColor].CGColor;
    label_3.layer.borderWidth = 1;
    
    UILabel *label_4 = [[UILabel alloc]initWithFrame:CGRectMake(270, 150, 2, 30)];
    label_4.layer.borderColor = [UIColor blackColor].CGColor;
    label_4.layer.borderWidth = 1;
    
    [self.view addSubview:label_3];
    [self.view addSubview:label_4];
    
    // 添加楚汉 河界
    UILabel *lbChuhan = [[UILabel alloc]initWithFrame:CGRectMake(90, 155, 50, 20)];
    lbChuhan.text = @"楚河";
    [self.view addSubview:lbChuhan];
    
    UILabel *lbHejie = [[UILabel alloc]initWithFrame:CGRectMake(160, 155, 50, 20)];
    lbHejie.text = @"汉界";
    [self.view addSubview:lbHejie];
    lbHejie.transform = CGAffineTransformMakeRotation(M_PI/1);
    
    
    // 添加斜线
    UILabel *x_1 = [[UILabel alloc]initWithFrame:CGRectMake(109, 60, 30 * 1.414 * 2, 2)];
    x_1.layer.borderColor = [UIColor blackColor].CGColor;
    x_1.layer.borderWidth = 1;
    x_1.transform = CGAffineTransformMakeRotation(M_PI/4);
    [self.view addSubview:x_1];
    UILabel *x_2 = [[UILabel alloc]initWithFrame:CGRectMake(109, 60, 30*1.414*2, 2)];
    x_2.layer.borderColor = [UIColor blackColor].CGColor;
    x_2.layer.borderWidth = 1;
    x_2.transform = CGAffineTransformMakeRotation(M_PI/-4);
    [self.view addSubview:x_2];
    
    // 添加斜线
    UILabel *x_3 = [[UILabel alloc]initWithFrame:CGRectMake(109, 270, 30 * 1.414 * 2, 2)];
    x_3.layer.borderColor = [UIColor blackColor].CGColor;
    x_3.layer.borderWidth = 1;
    x_3.transform = CGAffineTransformMakeRotation(M_PI/4);
    [self.view addSubview:x_3];
    UILabel *x_4 = [[UILabel alloc]initWithFrame:CGRectMake(109, 270, 30*1.414*2, 2)];
    x_4.layer.borderColor = [UIColor blackColor].CGColor;
    x_4.layer.borderWidth = 1;
    x_4.transform = CGAffineTransformMakeRotation(M_PI/-4);
    [self.view addSubview:x_4];
}

// 初始化棋子
-(void)InitChess
{
    for (int i = 1; i <= 9; i++) {
        for (int j = 1; j <= 10; j++) {
            // 设置所有棋子的落点
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(i *30  - 10, j* 30 -10, 20, 20);
            [btn.layer setCornerRadius:10];
            btn.backgroundColor = [UIColor clearColor];
            // 初始化初始棋子
            btn = [self GetBtnTextAndColor:i yPoints:j ButtonType:btn];
            // 设置btn的坐标
            btn.tag = (i+ j*10);
            [btn addTarget:self action:@selector(MoveChess:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
        }
    }
    // 重新开始的按钮
    btnStart = [UIButton buttonWithType:UIButtonTypeCustom];
    btnStart.frame = CGRectMake(100, 430, 100, 30);
    [btnStart setTitle:@"重新开始" forState:UIControlStateNormal];
    [btnStart addTarget:self action:@selector(GameNewStart) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btnStart];
}
-(void)JudgeWillKillBoss
{
    // 是否将军
    int result = [self WillBeKillBossChess];
    if (result == 1) {
        lbJiangJun.hidden = NO;
    }
    else if (result == 0){
        lbJiangJun.hidden = YES;
    }
}
// 重新开始游戏
-(void)GameNewStart
{
    // 设置所有 按钮不可使用
    for (int i = 1; i <= 9; i++) {
        for (int j = 1; j <= 10; j++) {
            UIButton *btn = (UIButton *)[self.view viewWithTag:i + 10*j];
            [btn removeFromSuperview];
        }
    }
    // 时间停止
    [timer invalidate];
    
    [_timer invalidate];
    
    [lbWhoCango removeFromSuperview];
    
    [lbTime removeFromSuperview];
    
    [lbJiangJun removeFromSuperview];
    
    [btnStart removeFromSuperview];
    
    btnClickChess = NULL;
    
    // 初始化棋盘
    //[self InitQipan];
    
    // 初始化棋子
    [self InitChess];
    
    // 设置时间,谁走，将军提示
    [self SetTimerLabel];
    
    // 首先设置红棋先走
    WhoCanGo = 1;
    
    JiangLocate = 15;
    ShuaiLocate = 105;
}

// 点击棋子可以后的移动和判断
-(void)MoveChess:(UIButton *)sender
{
    // 判断是哪一方走棋
    if (WhoCanGo == 1) {
        if (btnClickChess == NULL) {
            if (sender.backgroundColor != [UIColor redColor]) {
                return;
            }
        }
    }
    else if (WhoCanGo == 2)
    {
        if (btnClickChess == NULL) {
            if (sender.backgroundColor != [UIColor blackColor]) {
                return;
            }
        }
    }
    // 记录当前点击的棋子
    if (btnClickChess == NULL) {
        // 判断是否点击在空白的棋盘区域上
        if (sender.titleLabel.text) {
            btnClickChess = sender;
            btnClickChess.alpha = 0.5;
        }
        return;
    }
    
    // 判断是否取消当前点击的棋子(两次点击同一个棋子，则取消当前要移动的棋子)
    if (sender.tag == btnClickChess.tag) {
        btnClickChess.alpha = 1;
        btnClickChess = NULL;
        return;
    }
    
    // 判断是否是直接将对帅
    if (([btnClickChess.currentTitle isEqualToString:@"将"] && [sender.currentTitle isEqualToString:@"帅"])
        || ([btnClickChess.currentTitle isEqualToString:@"帅"] && [sender.currentTitle isEqualToString:@"将"])) {
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"游戏结束"  delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil, nil];
        [alert show];
        
        // 设置所有 按钮不可使用
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= 10; j++) {
                UIButton *btn = (UIButton *)[self.view viewWithTag:i + 10*j];
                btn.enabled = NO;
            }
        }
        // 时间停止
        [timer invalidate];
        return;
    }
    
    // 判断当前落点是否符合规则
    NSMutableArray *arry = [self GetMoveResult:btnClickChess FinishChess:sender];
    // 如果没有可落位置，则删除记录
    if (arry.count == 0) {
        btnClickChess.alpha = 1;
        btnClickChess = NULL;
        return;
    }
    BOOL _result = false;
    // 判断当前落点的坐标位置是否符合移动规则
    for (NSString *chess in arry) {
        // 判断是否可以落子
        if ([chess isEqualToString:[NSString stringWithFormat:@"%d", sender.tag]]) {
            _result = true;
        }
    }
    // 查看结果，为ture则移动棋子
    if (_result) {

        // 判断是否为游戏结束
        if ([sender.currentTitle isEqualToString:@"将"] || [sender.currentTitle isEqualToString:@"帅"]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"游戏结束"  delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil, nil];
            [alert show];
            
            // 设置所有 按钮不可使用
            for (int i = 1; i <= 9; i++) {
                for (int j = 1; j <= 10; j++) {
                    UIButton *btn = (UIButton *)[self.view viewWithTag:i + 10*j];
                    btn.enabled = NO;
                }
            }
            // 时间停止
            [timer invalidate];
            return;
        }
        
        // 改变棋子
        [sender setTitle:btnClickChess.currentTitle forState:UIControlStateNormal];
        [sender setBackgroundColor:btnClickChess.backgroundColor];

        // 判断当前移动的是否为 将 或者 帅
        if ([sender.currentTitle isEqualToString:@"将"]) {
            JiangLocate = sender.tag;
        }
        if ([sender.currentTitle isEqualToString:@"帅"]) {
            ShuaiLocate = sender.tag;
        }
        
        // 删除原位置的棋子
        [btnClickChess setTitle:NULL forState:UIControlStateNormal];
        btnClickChess.titleLabel.text = false;
        [btnClickChess setBackgroundColor:[UIColor clearColor]];
        btnClickChess.alpha = 1;
        btnClickChess = NULL;
        
        WhoCanGo = WhoCanGo == 1? 2 : 1;
        if (WhoCanGo == 1) {
            lbWhoCango.text = @"红棋 出手";
        }
        else
        {
            lbWhoCango.text = @"黑棋 出手";
        }
        
        return;
    }
    
    btnClickChess.alpha = 1;
    btnClickChess = NULL;
}

// 获取当前棋子的移动规则集合,根据棋子的坐标、以及派别（红方：下   黑方：上）
// 返回一个数组，表示可以移动的坐标的位置
-(NSMutableArray *)GetMoveResult:(UIButton *)startChess FinishChess:(UIButton*)endChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
  
    if ([startChess.titleLabel.text isEqualToString:@"兵"] || [startChess.titleLabel.text isEqualToString:@"卒"]) {
        arry = [self GetAimChessPoint:startChess];
    }
    else if ([startChess.titleLabel.text isEqualToString:@"炮"])
    {
        arry = [self GetPaoChessPoint:startChess];
    }
    else if ([startChess.currentTitle isEqualToString:@"車"] || [startChess.currentTitle isEqualToString:@"车"])
    {
        arry = [self GetCheChessPoint:startChess];
    }
    else if ([startChess.currentTitle isEqualToString:@"马"])
    {
        arry = [self GetHorseChessPoint:startChess];
    }
    else if ([startChess.currentTitle isEqualToString:@"相"])
    {
        arry = [self GetXiangChessPoint:startChess];
    }
    else if([startChess.currentTitle isEqualToString:@"象"])
    {
        arry = [self GetXiangChessPoints:startChess];
    }
    else if([startChess.currentTitle isEqualToString:@"仕"])
    {
        arry = [self GetShiChessPoint:startChess];
    }
    else if([startChess.currentTitle isEqualToString:@"士"])
    {
        arry = [self GetShiChessPoints:startChess];
    }
    else if([startChess.currentTitle isEqualToString:@"将"])
    {
        arry = [self GetBossChessPoint:startChess];
    }
    else if([startChess.currentTitle isEqualToString:@"帅"])
    {
        arry = [self GetBosschessPoints:startChess];
    }
    return arry;
}

// 获取 是否是 将军 了   不将军 返回0，  将军 返回1
-(int)WillBeKillBossChess
{
    // 将 帅
    UIButton *btnJiang = (UIButton *)[self.view viewWithTag:JiangLocate];
    // 分割将的坐标
    int x = JiangLocate % 10;
    int y = JiangLocate / 10;
    
    // 判断是否将军
    // 1: 車 将
    // 2: 卒 将
    // 3: 炮 将
    // 4: 马 将
    // 5: 帅 将
    
    // 先判断車将 左
    for (int i = x - 1; i > 0; i--) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: y*10 + i];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"車"]) {
                return 1;
            }
            // 卒 将
            if (i == x -1) {
                if ([btn.titleLabel.text isEqualToString:@"卒"]) {
                    return 1;
                }
            }
            // 炮 将
            for (int j = i - 1; j > 0; j--) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:y*10 + j];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnJiang.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 右边
    for (int i = x + 1; i <= 9; i++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: y*10 + i];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"車"]) {
                return 1;
            }
            // 卒 将
            if (i == x + 1) {
                if ([btn.titleLabel.text isEqualToString:@"卒"]) {
                    return 1;
                }
            }
            // 炮 将
            for (int j = i + 1; j <= 9; j++) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:y*10 + j];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnJiang.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 上边
    for (int j = y -1; j >= 1; j--) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: j*10 + x];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"車"]) {
                return 1;
            }
            // 炮 将
            for (int _j = j - 1; _j >= 1; _j--) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:_j*10 + x];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnJiang.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 下边
    for (int j = y + 1; j <= 10; j++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: j*10 + x];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"車"]) {
                return 1;
            }
            // 卒 将
            if (j == y + 1) {
                if ([btn.titleLabel.text isEqualToString:@"卒"]) {
                    return 1;
                }
            }
            // 帅 将
            if ([btn.titleLabel.text isEqualToString:@"帅"]) {
                return 1;
            }
            // 炮 将
            for (int _j = j + 1; _j <= 10; _j++) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:_j*10 + x];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnJiang.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 马 将
    {
        if (y - 2 > 0) {
            // 左上
            UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(y*10 - 20) + (x -1)];
            if ([btn_1.titleLabel.text isEqualToString:@"马"] && btn_1.backgroundColor != btnJiang.backgroundColor)
            {
                UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x -1)];
                if (!btn_2.titleLabel.text) {
                    return 1;
                }
            }
            // 右上
            UIButton *btn_3 = (UIButton *)[self.view viewWithTag:(y*10 - 20) + (x + 1)];
            if ([btn_3.titleLabel.text isEqualToString:@"马"] && btn_3.backgroundColor != btnJiang.backgroundColor)
            {
                UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x -1)];
                if (!btn_4.titleLabel.text) {
                    return 1;
                }
            }
        }
        if (y - 1 > 0) {
            // 左上
            UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x -2)];
            if ([btn_1.titleLabel.text isEqualToString:@"马"] && btn_1.backgroundColor != btnJiang.backgroundColor)
            {
                UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x -1)];
                if (!btn_2.titleLabel.text) {
                    return 1;
                }
            }
            // 右上
            UIButton *btn_3 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x + 2)];
            if ([btn_3.titleLabel.text isEqualToString:@"马"] && btn_3.backgroundColor != btnJiang.backgroundColor)
            {
                UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x + 1)];
                if (!btn_4.titleLabel.text) {
                    return 1;
                }
            }
        }
        // 左下1
        UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x - 2)];
        if ([btn_1.titleLabel.text isEqualToString:@"马"] && btn_1.backgroundColor != btnJiang.backgroundColor)
        {
            UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x -1)];
            if (!btn_2.titleLabel.text) {
                return 1;
            }
        }
        // 左上2
        UIButton *btn_3 = (UIButton *)[self.view viewWithTag:(y*10 + 20) + (x - 1)];
        if ([btn_3.titleLabel.text isEqualToString:@"马"] && btn_3.backgroundColor != btnJiang.backgroundColor)
        {
            UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x - 1)];
            if (!btn_4.titleLabel.text) {
                return 1;
            }
        }
        // 右下1
        UIButton *btn_11 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x + 2)];
        if ([btn_11.titleLabel.text isEqualToString:@"马"] && btn_11.backgroundColor != btnJiang.backgroundColor)
        {
            UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x + 1)];
            if (!btn_2.titleLabel.text) {
                return 1;
            }
        }
        // 右上2
        UIButton *btn_31 = (UIButton *)[self.view viewWithTag:(y*10 + 20) + (x + 1)];
        if ([btn_31.titleLabel.text isEqualToString:@"马"] && btn_31.backgroundColor != btnJiang.backgroundColor)
        {
            UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x + 1)];
            if (!btn_4.titleLabel.text) {
                return 1;
            }
        }
    }
    
    UIButton *btnShuai = (UIButton *)[self.view viewWithTag:ShuaiLocate];
    // 分割将的坐标
    int xpoint = ShuaiLocate % 10;
    int ypoint = ShuaiLocate / 10;
    
    // 判断是否将军
    // 1: 車 将
    // 2: 卒 将
    // 3: 炮 将
    // 4: 马 将
    // 5: 帅 将
    
    // 先判断車将 左
    for (int i = xpoint - 1; i > 0; i--) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: ypoint*10 + i];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"车"]) {
                return 1;
            }
            // 卒 将
            if (i == xpoint -1) {
                if ([btn.titleLabel.text isEqualToString:@"兵"]) {
                    return 1;
                }
            }
            // 炮 将
            for (int j = i - 1; j > 0; j--) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:ypoint*10 + j];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnShuai.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 右边
    for (int i = xpoint + 1; i <= 9; i++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: ypoint*10 + i];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"车"]) {
                return 1;
            }
            // 卒 将
            if (i == xpoint + 1) {
                if ([btn.titleLabel.text isEqualToString:@"兵"]) {
                    return 1;
                }
            }
            // 炮 将
            for (int j = i + 1; j <= 9; j++) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:ypoint*10 + j];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnShuai.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 上边
    for (int j = ypoint -1; j >= 1; j--) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: j*10 + xpoint];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"车"]) {
                return 1;
            }
            // 帅 将
            if ([btn.titleLabel.text isEqualToString:@"将"]) {
                return 1;
            }
            // 炮 将
            for (int _j = j - 1; _j >= 1; _j--) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:_j*10 + xpoint];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnShuai.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 下边
    for (int j = ypoint + 1; j <= 10; j++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag: j*10 + xpoint];
        if (btn.titleLabel.text) {
            // 车 将
            if ([btn.titleLabel.text isEqualToString:@"车"]) {
                return 1;
            }
            // 卒 将
            if (j == ypoint + 1) {
                if ([btn.titleLabel.text isEqualToString:@"兵"]) {
                    return 1;
                }
            }
            // 炮 将
            for (int _j = j + 1; _j <= 10; _j++) {
                UIButton *btnPao = (UIButton *)[self.view viewWithTag:_j*10 + xpoint];
                if (!btnPao.titleLabel.text) {
                    continue;
                }
                if ([btnPao.titleLabel.text isEqualToString:@"炮"] && btnPao.backgroundColor != btnShuai.backgroundColor) {
                    return 1;
                }
                break;
            }
            break;
        }
    }
    // 马 将
    {
        if (y == 8) {
            // 左下
            UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(y*10 + 20) + (x -1)];
            if ([btn_1.titleLabel.text isEqualToString:@"马"] && btn_1.backgroundColor != btnShuai.backgroundColor)
            {
                UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x -1)];
                if (!btn_2.titleLabel.text) {
                    return 1;
                }
            }
            // 右下
            UIButton *btn_3 = (UIButton *)[self.view viewWithTag:(y*10 + 20) + (x + 1)];
            if ([btn_3.titleLabel.text isEqualToString:@"马"] && btn_3.backgroundColor != btnShuai.backgroundColor)
            {
                UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x +1)];
                if (!btn_4.titleLabel.text) {
                    return 1;
                }
            }
        }
        if (y == 9) {
            // 左下
            UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x -2)];
            if ([btn_1.titleLabel.text isEqualToString:@"马"] && btn_1.backgroundColor != btnShuai.backgroundColor)
            {
                UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x -1)];
                if (!btn_2.titleLabel.text) {
                    return 1;
                }
            }
            // 右下
            UIButton *btn_3 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x + 2)];
            if ([btn_3.titleLabel.text isEqualToString:@"马"] && btn_3.backgroundColor != btnShuai.backgroundColor)
            {
                UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x + 1)];
                if (!btn_4.titleLabel.text) {
                    return 1;
                }
            }
        }
        // 左上1
        UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x - 2)];
        if ([btn_1.titleLabel.text isEqualToString:@"马"] && btn_1.backgroundColor != btnShuai.backgroundColor)
        {
            UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x -1)];
            if (!btn_2.titleLabel.text) {
                return 1;
            }
        }
        // 左上2
        UIButton *btn_3 = (UIButton *)[self.view viewWithTag:(y*10 - 20) + (x - 1)];
        if ([btn_3.titleLabel.text isEqualToString:@"马"] && btn_3.backgroundColor != btnShuai.backgroundColor)
        {
            UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x - 1)];
            if (!btn_4.titleLabel.text) {
                return 1;
            }
        }
        // 右上1
        UIButton *btn_11 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x + 2)];
        if ([btn_11.titleLabel.text isEqualToString:@"马"] && btn_11.backgroundColor != btnShuai.backgroundColor)
        {
            UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x + 1)];
            if (!btn_2.titleLabel.text) {
                return 1;
            }
        }
        // 右上2
        UIButton *btn_31 = (UIButton *)[self.view viewWithTag:(y*10 - 20) + (x + 1)];
        if ([btn_31.titleLabel.text isEqualToString:@"马"] && btn_31.backgroundColor != btnShuai.backgroundColor)
        {
            UIButton *btn_4 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x + 1)];
            if (!btn_4.titleLabel.text) {
                return 1;
            }
        }
    }

    return 0;
}



// 获取 帅 可以移动的位置
-(NSMutableArray *)GetBosschessPoints:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    int tag = startChess.tag;
    
    switch (tag) {
        case 84:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:85];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:94];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        case 85:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:84];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:95];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:86];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 86:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:85];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:96];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        case 94:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:84];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:95];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:104];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 95:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:85];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:94];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:105];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
            UIButton *btn3 = (UIButton *)[self.view viewWithTag:96];
            if (btn3.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn3.tag]];
            }
        }
            break;
        case 96:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:86];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:95];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:106];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 104:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:94];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:105];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        case 105:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:104];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:95];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:106];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 106:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:105];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:96];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        default:
            break;
    }
    return arry;
}

// 获取 将 可以移动的位置
-(NSMutableArray *)GetBossChessPoint:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    int tag = startChess.tag;
    
    switch (tag) {
        case 14:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:15];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:24];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        case 15:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:14];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:25];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:16];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 16:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:15];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:26];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        case 24:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:14];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:25];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:34];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 25:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:15];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:24];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:35];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
            UIButton *btn3 = (UIButton *)[self.view viewWithTag:26];
            if (btn3.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn3.tag]];
            }
        }
            break;
        case 26:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:16];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:25];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:36];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 34:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:24];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:35];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        case 35:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:34];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:25];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:36];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
        }
            break;
        case 36:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:35];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:26];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
        }
            break;
        default:
            break;
    }
    return arry;
}
// 获取 士 可以移动的位置
-(NSMutableArray *)GetShiChessPoints:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    int tag = startChess.tag;
    switch (tag) {
        case 84:
        case 104:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:95];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
        }
            break;
        case 86:
        case 106:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:95];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
        }
            break;
        case 95:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:84];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:86];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:104];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
            UIButton *btn3 = (UIButton *)[self.view viewWithTag:106];
            if (btn3.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn3.tag]];
            }
        }
            break;
        default:
            break;
    }
    return arry;
}

// 获取 仕可以移动的位置
-(NSMutableArray *)GetShiChessPoint:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    int tag = startChess.tag;
    switch (tag) {
        case 14:
        case 34:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:25];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
        }
            break;
        case 16:
        case 36:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:25];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
        }
            break;
        case 25:
        {
            UIButton *btn = (UIButton *)[self.view viewWithTag:14];
            if (btn.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:16];
            if (btn1.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
            }
            UIButton *btn2 = (UIButton *)[self.view viewWithTag:34];
            if (btn2.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
            }
            UIButton *btn3 = (UIButton *)[self.view viewWithTag:36];
            if (btn3.backgroundColor != startChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn3.tag]];
            }
        }
            break;
        default:
            break;
    }
    return arry;
}


// 获取 象 可以移动的位置
-(NSMutableArray *)GetXiangChessPoints:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    int tag = startChess.tag;
    switch (tag) {
        case 63:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:72];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:81];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:74];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:85];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 67:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:76];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:85];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:78];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:89];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 81:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:72];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:63];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:92];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:103];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 85:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:74];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:63];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:76];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:67];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
            UIButton *btn3 = (UIButton *)[self.view viewWithTag:94];
            if (!btn3.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:103];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn4 = (UIButton *)[self.view viewWithTag:96];
            if (!btn4.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:107];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 89:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:78];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:67];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:98];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:107];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 103:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:92];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:81];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:94];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:85];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 107:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:96];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:85];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:98];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:89];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        default:
            break;
    }
    return arry;
}

// 获取 相 可以移动的位置
-(NSMutableArray *)GetXiangChessPoint:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    int tag = startChess.tag;
    switch (tag) {
        case 13:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:22];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:31];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:24];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:35];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 17:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:26];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:35];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:28];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:39];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 31:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:22];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:13];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:42];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:53];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 35:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:24];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:13];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:26];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:17];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
            UIButton *btn3 = (UIButton *)[self.view viewWithTag:44];
            if (!btn3.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:53];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn4 = (UIButton *)[self.view viewWithTag:46];
            if (!btn4.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:57];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 39:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:28];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:17];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:48];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:57];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 53:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:42];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:31];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:44];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:35];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        case 57:
        {
            // 判断是否把相阻挡了
            UIButton *btn = (UIButton *)[self.view viewWithTag:46];
            if (!btn.titleLabel.text) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:35];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            UIButton *btn1 = (UIButton *)[self.view viewWithTag:48];
            if (!btn1.titleLabel.text) {
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:39];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
            break;
        default:
            break;
    }
    
    
    return arry;
}


// 获取 马 可以移动的位置
-(NSMutableArray *)GetHorseChessPoint:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    
    // 得到马当前的位置
    int x = (startChess.tag )%10;
    int y = (startChess.tag )/10;
    
    // 如果不上撇脚马，则可以移动的位置为八个
    //先判断 上方 是否可以移动
    if (y*10 >= 30) {
        // 判断是否 撇脚 若不撇脚，则将上方可以移动的位置坐标添加进去
        UIButton *btn = (UIButton *)[self.view viewWithTag:(y*10 -10 + x)];
        if (!btn.titleLabel.text) {
            // 判断左上边是否可以落子
            if (x > 1) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:(y*10 - 20) + (x - 1)];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            if (x < 9) {
                // 判断右上边是否可以落子
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:(y*10 - 20) + (x + 1)];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
    }
    
    // 判断 左方 是否可以移动
    if (x >= 3) {
        // 判断是否 撇脚
        UIButton *btn = (UIButton *)[self.view viewWithTag:y*10 + (x -1)];
        if (!btn.titleLabel.text) {
            // 判断左上方是否可以落子
            if (y*10 > 10) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x - 2)];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            // 判断左下方是否可以落子
            if (y*10 < 100) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x - 2)];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
        }
    }
    
    // 判断 下方 是否可以移动
    if (y*10 <= 80) {
        // 判断是否 撇脚 若不撇脚，则将上方可以移动的位置坐标添加进去
        UIButton *btn = (UIButton *)[self.view viewWithTag:(y*10 +10 + x)];
        if (!btn.titleLabel.text) {
            // 判断左下边是否可以落子
            if (x > 1) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:(y*10 + 20) + (x - 1)];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            if (x < 9) {
                // 判断右下边是否可以落子
                UIButton *btn2 = (UIButton *)[self.view viewWithTag:(y*10 + 20) + (x + 1)];
                if (btn2.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn2.tag]];
                }
            }
        }
    }
    
    // 判断 右方 是否可以移动
    if (x <= 7) {
        // 判断是否 撇脚
        UIButton *btn = (UIButton *)[self.view viewWithTag:y*10 + (x + 1)];
        if (!btn.titleLabel.text) {
            // 判断右上方是否可以落子
            if (y*10 > 10) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:(y*10 - 10) + (x + 2)];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
            // 判断右下方是否可以落子
            if (y*10 < 100) {
                UIButton *btn1 = (UIButton *)[self.view viewWithTag:(y*10 + 10) + (x + 2)];
                if (btn1.backgroundColor != btnClickChess.backgroundColor) {
                    [arry addObject:[NSString stringWithFormat:@"%d", btn1.tag]];
                }
            }
        }
    }
    return arry;
}

// 获取 車 可以移动的位置
-(NSMutableArray *)GetCheChessPoint:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    // 得到車当前的位置
    int x = (startChess.tag )%10;
    int y = (startChess.tag )/10;
    
    // 先查找横向可以移动到的位置
    for (int i = x + 1; i <= 9; i++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:i +y*10];
        if (btn.titleLabel.text) {
            // 吃  如果不同阵营，则可以吃
            if (btn.backgroundColor != btnClickChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            break;
        }
        [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
    }
    for (int i = x -1; i >= 1; i--) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:i +y*10];
        if (btn.titleLabel.text) {
            // 吃  如果不同阵营，则可以吃
            if (btn.backgroundColor != btnClickChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            break;
        }
        [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
    }
    // 纵向可以移动的位置
    for (int i = y + 1; i <= 10; i++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:i*10 +x];
        if (btn.titleLabel.text) {
            // 吃  如果不同阵营，则可以吃
            if (btn.backgroundColor != btnClickChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            break;
        }
        [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
    }
    for (int i = y -1; i >= 1; i--) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:i*10 +x];
        if (btn.titleLabel.text) {
            // 吃  如果不同阵营，则可以吃
            if (btn.backgroundColor != btnClickChess.backgroundColor) {
                [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
            }
            break;
        }
        [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
    }
    return arry;
}

// 获取 兵 可以移动的位置
-(NSMutableArray *)GetAimChessPoint:(UIButton *)startChess
{
    // 用于记录当前起始棋子可以落点的位置的坐标
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    
    // 判断当前是属于哪一方
    // 黑方
    if (startChess.backgroundColor == [UIColor blackColor]) {
        // 设置移动规则
        // 兵
        if ([startChess.titleLabel.text isEqualToString:@"兵"]) {
            // 兵在本方时，只可前进一步
            if ((startChess.tag )/10 <= 5) {
                // 判断前边是否有本方棋子挡住
                UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag + 10)];
                // 没有本方的棋子抵挡，则可以移动
                if (btn.backgroundColor != [UIColor blackColor]) {
                    [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 10)]];
                }
            }
            else// 在敌方阵营时，可左右移动和前进
            {
                // 判断时否是边兵
                if ((startChess.tag ) / 10 == 1) {
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag + 10)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 10)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(startChess.tag + 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_1.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 1)]];
                    }
                }
                else if ((startChess.tag) / 10 == 9)
                {
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag + 10)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 10)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(startChess.tag - 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_1.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 1)]];
                    }
                }
                else
                {
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag + 10)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 10)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(startChess.tag - 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_1.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 1)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(startChess.tag + 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_2.backgroundColor != [UIColor blackColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 1)]];
                    }
                }
            }
        }
    }
    // 红方
    else
    {
        // 卒
        if ([startChess.titleLabel.text isEqualToString:@"卒"]) {
            // 兵在本方时，只可前进一步
            if ((startChess.tag )/10 > 5) {
                // 判断前边是否有本方棋子挡住
                UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag - 10)];
                // 没有本方的棋子抵挡，则可以移动
                if (btn.backgroundColor != [UIColor redColor]) {
                    [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 10)]];
                }
            }
            else        // 在敌方阵营时，可左右移动和前进
            {
                // 判断时否是边兵
                if ((startChess.tag) / 10 == 1) {
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag - 10)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 10)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(startChess.tag + 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_1.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 1)]];
                    }
                }
                else if ((startChess.tag) / 10 == 9)
                {
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag - 10)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 10)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(startChess.tag - 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_1.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 1)]];
                    }
                }
                else
                {
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn = (UIButton *)[self.view viewWithTag:(startChess.tag - 10)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 10)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_1 = (UIButton *)[self.view viewWithTag:(startChess.tag - 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_1.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag - 1)]];
                    }
                    // 判断前边是否有本方棋子挡住
                    UIButton *btn_2 = (UIButton *)[self.view viewWithTag:(startChess.tag + 1)];
                    // 没有本方的棋子抵挡，则可以移动
                    if (btn_2.backgroundColor != [UIColor redColor]) {
                        [arry addObject:[NSString stringWithFormat:@"%d", (startChess.tag + 1)]];
                    }
                }
            }
        }
    }
    return arry;
}

// 获取 炮 可以移动的位置
-(NSMutableArray *)GetPaoChessPoint:(UIButton *)startChess
{
    NSMutableArray *arry = [[NSMutableArray alloc]init];
    // 炮
    if ([startChess.titleLabel.text isEqualToString:@"炮"]) {
        // 得到炮当前的位置
        int x = (startChess.tag )%10;
        int y = (startChess.tag )/10;
        
        // 先查找横向可以移动到的位置
        for (int i = x + 1; i <= 9; i++) {
            UIButton *btn = (UIButton *)[self.view viewWithTag:i +y*10];
            if (btn.titleLabel.text) {
                // 需要炮打翻山
                for (int j = i + 1; j <= 9; j++) {
                    UIButton *btn = (UIButton *)[self.view viewWithTag:j +y*10];
                    if (btn.titleLabel.text) {
                        if (btn.backgroundColor != btnClickChess.backgroundColor) {
                            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
                        }
                        break;
                    }
                }
                break;
            }
            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
        }
        for (int i = x -1; i >= 1; i--) {
            UIButton *btn = (UIButton *)[self.view viewWithTag:i +y*10];
            if (btn.titleLabel.text) {
                // 需要炮打翻山
                for (int j = i - 1; j >= 1; j--) {
                    UIButton *btn = (UIButton *)[self.view viewWithTag:j +y*10];
                    if (btn.titleLabel.text) {
                        if (btn.backgroundColor != btnClickChess.backgroundColor) {
                            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
                        }
                        break;
                    }
                }
                break;
            }
            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
        }
        // 纵向可以移动的位置
        for (int i = y + 1; i <= 10; i++) {
            UIButton *btn = (UIButton *)[self.view viewWithTag:i*10 +x];
            if (btn.titleLabel.text) {
                // 需要炮打翻山
                for (int j = i + 1; j <= 10; j++) {
                    UIButton *btn = (UIButton *)[self.view viewWithTag:j*10 +x];
                    if (btn.titleLabel.text) {
                        if (btn.backgroundColor != btnClickChess.backgroundColor) {
                            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
                        }
                        break;
                    }
                }
                break;
            }
            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
        }
        for (int i = y -1; i >= 1; i--) {
            UIButton *btn = (UIButton *)[self.view viewWithTag:i*10 +x];
            if (btn.titleLabel.text) {
                // 需要炮打翻山
                for (int j = i - 1; j >= 1; j--) {
                    UIButton *btn = (UIButton *)[self.view viewWithTag:j*10 +x];
                    if (btn.titleLabel.text) {
                        if (btn.backgroundColor != btnClickChess.backgroundColor) {
                            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
                        }
                        break;
                    }
                }
                break;
            }
            [arry addObject:[NSString stringWithFormat:@"%d", btn.tag]];
        }
    }
    return arry;
}

// 根据坐标初始化填充棋子，name 为1 则表示为黑方，为2表示红方
// 如果当前坐标不需要棋子，则返回为nil
-(UIButton *)GetBtnTextAndColor:(NSInteger)x yPoints:(NSInteger)y ButtonType:(UIButton *)sender
{
    [sender setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    if (y == 1) {
        switch (x) {
            case 1:
            case 9:
                [sender setTitle:@"车" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor blackColor];
                break;
            case 2:
            case 8:
                [sender setTitle:@"马" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor blackColor];
                break;
            case 3:
            case 7:
                [sender setTitle:@"相" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor blackColor];
                break;
            case 4:
            case 6:
                [sender setTitle:@"仕" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor blackColor];
                break;
            case 5:
                [sender setTitle:@"将" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor blackColor];
                break;
            default:
                break;
        }
    }
    else if (y == 10)
    {
        switch (x) {
            case 1:
            case 9:
                [sender setTitle:@"車" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor redColor];
                break;
            case 2:
            case 8:
                [sender setTitle:@"马" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor redColor];
                break;
            case 3:
            case 7:
                [sender setTitle:@"象" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor redColor];
                break;
            case 4:
            case 6:
                [sender setTitle:@"士" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor redColor];
                break;
            case 5:
                [sender setTitle:@"帅" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor redColor];
                break;
            default:
                break;
        }
    }
    else if ( y == 3 || y == 8)
    {
        switch (x) {
            case 2:
            case 8:
                [sender setTitle:@"炮" forState:UIControlStateNormal];
                sender.backgroundColor = y == 3? [UIColor blackColor] : [UIColor redColor];
                break;
            default:
                break;
        }
    }
    else if(y == 4)
    {
        switch (x) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 9:
                [sender setTitle:@"兵" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor blackColor];
            default:
                break;
        }
    }
    else if(y == 7)
    {
        switch (x) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 9:
                [sender setTitle:@"卒" forState:UIControlStateNormal];
                sender.backgroundColor = [UIColor redColor];
            default:
                break;
        }

    }
    return  sender;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

}

@end
