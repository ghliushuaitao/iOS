//
//  XFLSoundManager.m
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-24.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import "XFLSoundManager.h"



#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>

@implementation XFLSoundManager

//要想播放音频需要音频的本地URL(统一资源定位符)
+ (NSURL *)getURLWithName:(NSString *)name
{
    NSArray * array = [name componentsSeparatedByString:@"."];
    //mainBundle 单例，返回当前工程的包
    NSString * path = [[NSBundle mainBundle] pathForResource:array[0] ofType:array[1]];
    //返回制定音频文件的路径
    
    //创建本地URL
    NSURL * url = [NSURL fileURLWithPath:path];
    return  url;
}

//根据URL，播放短音频
+ (void)playShortSoundWithName:(NSString *)soundName
{
    SystemSoundID soundID;
    //声明soundID
    //绑定音频的URL和soundID
    AudioServicesCreateSystemSoundID((CFURLRef)[self getURLWithName:soundName], &soundID);
    //soundID就关联了音频文件
    
    //委托系统替我们播放这个音频，适合短于30秒的音频
    AudioServicesPlayAlertSound(soundID);
}

+(void)touchSound
{
    [self playShortSoundWithName:@"punch.wav"];
}

+ (void)shootSound
{
    [self playShortSoundWithName:@"pipe.mp3"];
}

+ (void)killEnemy
{
    NSUInteger i = arc4random() % 3 + 1;
    //i == 1 2 3
    NSString * name = [NSString stringWithFormat:@"enemy%d_down.mp3", i];
    [self playShortSoundWithName:name];
}

+ (void)gameOver
{
    [self playShortSoundWithName:@"punch3.mp3"];
}

+ (void)bgm
{
    //一个player对象，只能播放一只音乐
    AVAudioPlayer * player = [[AVAudioPlayer alloc] initWithContentsOfURL:[self getURLWithName:@"game_music.mp3"] error:nil];
    
    //设置循环次数
    player.numberOfLoops = -1;
    
    //准备播放
    [player prepareToPlay];
    
    //播放
    [player play];
    
    
}


@end
