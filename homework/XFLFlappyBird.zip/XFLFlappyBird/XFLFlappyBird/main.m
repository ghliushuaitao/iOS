//
//  main.m
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-23.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XFLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XFLAppDelegate class]));
    }
}
