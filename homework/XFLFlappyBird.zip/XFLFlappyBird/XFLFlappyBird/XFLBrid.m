//
//  XFLBrid.m
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-23.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import "XFLBrid.h"
#define BRID_FRAME CGRectMake(140, 380, 39, 29)
@implementation XFLBrid

- (id)init
{
    if (self = [super initWithFrame:BRID_FRAME]) {
        self.image = [UIImage imageNamed:@"06.png"];
        self.backgroundColor = [UIColor clearColor];
        self.center = CGPointMake(80, 284);
        [self createAnimation];
    }
    return self;
}

-(void)createAnimation
{
    NSMutableArray * bridImages = [[NSMutableArray alloc] init];
    for (int i = 6; i <=9 ; i++) {
        UIImage * image;
        if (i == 9) {
            image = [UIImage imageNamed:@"07.png"];
        }else{
        image = [UIImage imageNamed:[NSString stringWithFormat:@"0%d.png",i]];
        }
        [bridImages addObject:image];
    }
    
    self.animationImages = bridImages;
    self.animationDuration = 0.5;
    self.animationRepeatCount = 0;
    
    [self startAnimating];
    [bridImages release];
}

-(void)gameOver
{
    [self stopAnimating];
    
}

-(void)down
{
    CGRect rect = self.frame;
    rect.origin.y = 430;
    self.frame = rect;
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
