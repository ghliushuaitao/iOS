//
//  XFLLand.h
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-24.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFLLand : UIImageView

@property (readonly)BOOL isMove;

-(void)moveLeft;
//-(void)reset;
-(void)startMove;

@end
