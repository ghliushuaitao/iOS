//
//  XFLAppDelegate.h
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-23.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
