//
//  XFLSoundManager.h
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-24.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XFLSoundManager : NSObject
//播放设计音频
+(void)touchSound;

+ (void)shootSound;

+ (void)killEnemy;

+ (void)gameOver;

+ (void)bgm;

@end
