//
//  XFLLand.m
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-24.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import "XFLLand.h"

@implementation XFLLand

-(id)init
{
//    CGRect rect;
    //    rect.origin = PIPE_ORIGIN;
//    rect.size = CGSizeMake(336, 112);
//    rect.origin = CGPointMake(320, 37);
    if (self = [super initWithFrame:CGRectMake(0, 450, 336, 112)]) {
        self.image = [UIImage imageNamed:@"03.png"];
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(void)moveLeft
{
    if (_isMove == NO) {
        return;
    }
    CGRect rect = self.frame;
    rect.origin.x -= 9;
    self.frame = rect;
    
    if (self.frame.origin.x < -10) {
        [self reset];
    }
}

-(void)reset
{
    CGRect rect = self.frame;
    rect = CGRectMake(0, 460, 336, 112);
    self.frame = rect;
    
    _isMove = NO;
}

-(void)startMove
{
    _isMove = YES;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
