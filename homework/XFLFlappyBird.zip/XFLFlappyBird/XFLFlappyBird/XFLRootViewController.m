//
//  XFLRootViewController.m
//  XFLFlappyBird
//
//  Created by 薛飞龙 on 14-5-23.
//  Copyright (c) 2014年 FLonger. All rights reserved.
//

#import "XFLRootViewController.h"
#import "XFLBrid.h"
#import "XFLPipe.h"
#import "XFLWihteBlock.h"
#import "XFLPipeUp.h"
#import "XFLLand.h"
#import "XFLSoundManager.h"
int i = 0;

@interface XFLRootViewController ()

@end

@implementation XFLRootViewController
{
    //创建定时器
    NSTimer * _timer;
    
    NSMutableArray * _landArray;
    NSMutableArray * _upPipe;
    NSMutableArray * _wihteBlock;
    NSMutableArray * _downPipe;
    BOOL _isUp;
    BOOL _isOver;
}

-(void)dealloc
{
    if (_timer) {
        [_timer invalidate];
    }
    [_landArray release];
    [_upPipe release];
    [_downPipe release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createSuperView];
    [self createSubView];
    [self createLand];
    [self createBrid];
    [self createP];
    [self createTimer];

//    XFLBrid * bird = (id)[[self.view viewWithTag:11] viewWithTag:22];
//    UIButton * button = (id)[[self.view viewWithTag:11] viewWithTag:12];
//    [[self.view viewWithTag:11] bringSubviewToFront:button];
//    [button addTarget:bird action:@selector(birdUp) forControlEvents:UIControlEventTouchDown];
//    _isUp = YES;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - 创建总背景
-(void)createSuperView
{
    UIView * superView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 568)];
    superView.backgroundColor = [UIColor clearColor];
    superView.tag = 11;
    [self.view addSubview:superView];
    UIButton * button = [[UIButton alloc] initWithFrame:CGRectMake(0, 20, 320, 588)];
    button.backgroundColor = [UIColor clearColor];
    button.tag = 12;
    [superView addSubview:button];
    [button release];
    [superView release];
    
}
#pragma mark - 创建背景
-(void)createSubView
{
    UIView * backGround = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 537)];
    backGround.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.jpg"]];
//    backGround.alpha = 0.5;
    [[self.view viewWithTag:11] addSubview:backGround];
    [backGround release];

}

#pragma mark - 创建草地
-(void)createLand
{
    XFLLand * land = [[XFLLand alloc] init];
    land.tag = 13;
    [[self.view viewWithTag:11] addSubview:land];
    [land release];
}

-(void)landMove
{
    XFLLand * land = (id)[self.view viewWithTag:13];
    [land startMove];
    [land moveLeft];
}


#pragma mark - 创建定时器
-(void)createTimer
{
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(run) userInfo:nil repeats:YES];
}

-(void)run
{
    [self landMove];
    [self moveP];
    [self birdAction];
    [self checkAttack];
}

-(void)checkAttack
{
    XFLBrid * bird = (id)[[self.view viewWithTag:11] viewWithTag:22];
    for (XFLPipeUp * up in _upPipe) {
        if (CGRectIntersectsRect(bird.frame, up.frame) == YES) {
            [bird gameOver];
            [self gameOver];
            return;
        }
    }

    for (XFLPipe * down in _downPipe) {
        if (CGRectIntersectsRect(bird.frame, down.frame) == YES) {
            [bird gameOver];
            [self gameOver];
            return;
        }
    }
    for (XFLWihteBlock * block in _wihteBlock) {
        if (CGRectIntersectsRect(bird.frame, block.frame) == YES) {
            [XFLSoundManager shootSound];
            i++;
        }
    }
}

-(void)gameOver
{
    
    [_timer setFireDate:[NSDate distantFuture]];
    _isOver = YES;
    [XFLSoundManager gameOver];
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"Game Over" message:[NSString stringWithFormat:@"总分:%d分",i] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alertView show];
    [alertView release];
}

#pragma mark - 鸟相关
-(void)createBrid
{
    XFLBrid * brid = [[XFLBrid alloc] init];
    [[self.view viewWithTag:11] addSubview:brid];
    brid.tag = 22;
    [brid release];
}

-(void)birdAction
{
    if (_isUp == YES) {
        [self birdUp];
    }else{
        [self birdDown];
    }
}

-(void)birdDown
{
    XFLBrid * bird = (id)[[self.view viewWithTag:11] viewWithTag:22];
    CGRect rect = bird.frame;
    rect.origin.y +=10;
    if (rect.origin.y >= 430) {
//        bird.transform = CGAffineTransformMakeRotation(M_PI_4);
        [self gameOver];
        [bird gameOver];
    }
    bird.frame = rect;
}


-(void)birdUp
{
    XFLBrid * bird = (id)[[self.view viewWithTag:11] viewWithTag:22];
    CGRect rect = bird.frame;
    rect.origin.y -=20;
    bird.frame = rect;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_isOver == YES) {
        return;
    }
    _isUp = YES;
    [XFLSoundManager touchSound];
    [self birdAction];
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_isOver == YES) {
        return;
    }
    _isUp = NO;
    [self birdAction];
}

#pragma mark - 管道相关
-(void)createP
{
    _upPipe = [[NSMutableArray alloc] init];
    _wihteBlock = [[NSMutableArray alloc] init];
    _downPipe = [[NSMutableArray alloc] init];
    for (int i = 0; i < 5000; i++) {
        XFLPipeUp * up = [[XFLPipeUp alloc] init];
        XFLWihteBlock * block = [[XFLWihteBlock alloc] init];
        XFLPipe * down =[[XFLPipe alloc] init];
        int h = arc4random()%220;
        CGRect upF = up.frame;
        upF.origin = CGPointMake(400, -260+h);
        up.frame = upF;
        
        CGRect blockF = block.frame;
        blockF.origin = CGPointMake(400, 57.5+h);
        blockF.size = CGSizeMake(10, 115);
        block.frame = blockF;
        
        CGRect downF = down.frame;
        downF.origin = CGPointMake(400, 180+h);
        down.frame = downF;
        
        [[self.view viewWithTag:11] addSubview:up];
        [[self.view viewWithTag:11] addSubview:block];
        [[self.view viewWithTag:11] addSubview:down];
        [[self.view viewWithTag:11] insertSubview:up belowSubview:[self.view viewWithTag:13]];
        [[self.view viewWithTag:11] insertSubview:block belowSubview:[self.view viewWithTag:13]];
        [[self.view viewWithTag:11] insertSubview:down belowSubview:[self.view viewWithTag:13]];
        [_upPipe addObject:up];
        [_wihteBlock addObject:block];
        [_downPipe addObject:down];
        [up release];
        [block release];
        [down release];
    }
}

-(void)moveP
{
    for (XFLPipeUp * up in _upPipe) {
        [up moveLeft];
    }
    for (XFLWihteBlock * block in _wihteBlock) {
        [block moveLeft];
    }
    for (XFLPipe * down in _downPipe) {
        [down moveLeft];
    }
    static int x = 0;
    if (x++ % 5 != 0) {
        return;
    }
    XFLPipeUp * upPipe;
    XFLWihteBlock * wihteBlock;
    XFLPipe * downPipe;
    int ret;
A:
    ret = arc4random()%5000;
    upPipe = _upPipe[ret];
    if (upPipe.isMove == YES) {
        goto A;
    }
    wihteBlock = _wihteBlock[ret];
    if (wihteBlock.isMove == YES) {
        goto A;
    }
    downPipe = _downPipe[ret];
    if (downPipe.isMove == YES) {
        goto A;
    }
    [upPipe startMove];
    [wihteBlock startMove];
    [downPipe startMove];
}





@end
