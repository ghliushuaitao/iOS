//
//  AppDelegate.h
//  CatchCrazyCat
//
//  Created by WH on 15-4-27.
//  Copyright (c) 2015年 LiQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
