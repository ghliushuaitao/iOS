//
//  ViewController.m
//  CatchCrazyCat
//
//  Created by WH on 15-4-27.
//  Copyright (c) 2015年 LiQiang. All rights reserved.
//

#import "ViewController.h"
#import "drawCircle.h"

@interface ViewController ()
{
    drawCircle * circle[121];
    int diameter;
    int cat ;
    UITextView * label;
    UIButton  * btnrestart;
    UIAlertView *alter;
    int count;
    int zacount;
    UIButton * normal;
    UIButton * easy;
    UIButton * veryeasy;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createUI];
}

-(void)createUI{
    //障碍物 10个
    zacount = 10;
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGSize size = rect.size;
    CGFloat width = size.width;
    //尺寸 游戏视图
    diameter = width/11.5;
    
    //创建游戏的所有格子
    for (int i = 0; i<11; i++) {
        for (int j = 0; j<11; j++) {
            if ((i%2)!=0) {
                //偶数行
                circle[i*11+j] = [[drawCircle alloc]initWithFrame:CGRectMake(0+j*diameter+diameter/2, 20+i*diameter, diameter, diameter)];
            }else{
                //奇数行
                circle[i*11+j] = [[drawCircle alloc]initWithFrame:CGRectMake(0+j*diameter, 20+i*diameter, diameter, diameter)];
            }
            
            circle[i*11+j].backgroundColor = [UIColor whiteColor];
            [circle[i*11+j] setdiameter:0 :0 :diameter];
            [circle[i*11+j] setBackgroundColor:[UIColor colorWithRed:83 green:83 blue:83 alpha:1.0]];
            circle[i*11+j].userInteractionEnabled = YES;
            UITapGestureRecognizer *tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(event:)];
            [circle[i*11+j] addGestureRecognizer:tapGesture];

            [self.view addSubview:circle[i*11+j]];
        }
    }

    alter = [[UIAlertView alloc] initWithTitle:@"标题一定要长" message:@"you lose!" delegate:self cancelButtonTitle:@"cancle" otherButtonTitles:@"重来",nil];
    label  = [[UITextView alloc]init];
    [label setFrame:CGRectMake(0, 20+diameter*11, width, 50)];
    [label setUserInteractionEnabled:false];
    [self.view addSubview:label];
    
/*
    btnrestart = [[UIButton alloc]init];
    [btnrestart setFrame:CGRectMake(0, 70+diameter*11, width, 50)];
    [btnrestart setTitle:@"戳我刷新" forState:UIControlStateNormal];
    [btnrestart setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnrestart addTarget:self action:@selector(initgame) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnrestart];
    
    normal = [[UIButton alloc]init];
    [normal setFrame:CGRectMake(0, 120+diameter*11, width/3, 20)];
    [normal setTitle:@"普通" forState:UIControlStateNormal];
    [normal setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [normal addTarget:self action:@selector(changenormal) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:normal];
    
    easy = [[UIButton alloc]init];
    [easy setFrame:CGRectMake(width/3, 120+diameter*11, width/3, 20)];
    [easy setTitle:@"简单" forState:UIControlStateNormal];
    [easy setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [easy addTarget:self action:@selector(changeeasy) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:easy];
    
    veryeasy = [[UIButton alloc]init];
    [veryeasy setFrame:CGRectMake(width/3*2, 120+diameter*11, width/3, 20)];
    [veryeasy setTitle:@"非常简单" forState:UIControlStateNormal];
    [veryeasy setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [veryeasy addTarget:self action:@selector(changeveryeasy) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:veryeasy];
*/
    
    [self initgame];
    
}
-(void)changenormal{
    zacount = 10;
    [self initgame];
}
-(void)changeeasy{
    zacount = 66;
    [self initgame];
}
-(void)changeveryeasy{
    zacount = 111;
    [self initgame];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1)
    { [self initgame]; }
}
-(int) getDistance:(int) one :(int) dir{
    int distance = 0;
    if ([self isAtEdge:one]) {
        return 1;
    }
    int ori = one;
    int next;
    while (true) {
        next = [self getNeighbour:ori :dir];
        if ([circle[next] getcolor_num]==1) {
            return  distance*-1;
        }
        if ([self isAtEdge:next]) {
            distance++;
            return  distance;
        }
        distance++;
        ori = next;
    }
}
-(void)MoveTo:(int) one{
    [circle[one] setcolor_num:2];
    [circle[one] setNeedsDisplay];
    [circle[cat] setcolor_num:0];
    [circle[cat] setNeedsDisplay];
    cat = one;
}
-(void)lose{
    [alter setMessage:@"you lose!"];
    [alter show];

}
-(void)win{
    [alter setMessage:[NSString stringWithFormat:@"you win!共用了%d步",count]];
    [alter show];
}

-(void)move{
    if ([self isAtEdge:cat]) {
        [self lose];
        return ;
    }
    int a[7],b[7];
    int j = 0;
    NSMutableArray * avaliable = [NSMutableArray array];
    NSMutableArray * positive = [NSMutableArray array];
    for (int i = 1 ; i<7; i++) {
        int n = [self getNeighbour:cat :i];
        if ([circle[n] getcolor_num] == 0) {
            [avaliable addObject:[NSString stringWithFormat:@"%d",n]];
            a[j] = n;
            b[j] = i;
            j++;
            if ([self getDistance:n :i]>0) {
                [positive addObject:[NSString stringWithFormat:@"%d",n]];
            }
        }
    }
    if ([avaliable count]==0) {
        [self win];
        return ;
    }else if(avaliable.count==1){
        [self MoveTo:[[avaliable objectAtIndex:0] integerValue]];
    }else {
        int best = 0;
        if (positive.count!=0) {
            int min = 999;
            for (int i = 0; i<positive.count; i++) {
                int dir = b[[self returnb:a :[[positive objectAtIndex:i] integerValue]]];
                int ad = [self getDistance:[[positive objectAtIndex:i] integerValue] :dir];
                if (ad<min) {
                    min = ad;
                    best = [[positive objectAtIndex:i] integerValue];
                }
            }
        }else{
            int max = 0;
            for (int i = 0; i< avaliable.count; i++) {
                int dir2 = b[[self returnb:a :[[avaliable objectAtIndex:i] integerValue]]];
                int k = [self getDistance:[[avaliable objectAtIndex:i] integerValue] :dir2];
                if (k <= max) {
                    max = k;
                    best =[[avaliable objectAtIndex:i] integerValue];
                }
            }
        }
        NSLog(@"%d",best);
        [self MoveTo:best];
    }
    
    
}
-(int)returnb:(int *)a :(int) n {
    for (int i = 0; i<7; i++) {
        if(a[i]==n){
            return  i;
        }
    }
    return -1;
}
-(Boolean)isAtEdge:(int) one{
    if ((one/11)==0||(one%11)==0||(one)/11==10||(one)%11==10) {
        return true;
    }
    return false;
}
-(int) getNeighbour:(int) one :(int) dir{
    switch (dir) {
        case 1:
            return one - 1;
            break;
        case 2:
            if ((one/11)%2!=0) {
                return  one-11;
            }else{
                return one - 12;
            }
            break;
        case 3:
            if ((one/11)%2!=0) {
                return  one-10;
            }else{
                return one - 11;
            }
            break;
        case 4:
            return one + 1;
            break;
        case 5:
            if ((one/11)%2!=0) {
                return  one+12;
            }else{
                return one+11;
            }
            break;
        case 6:
            if ((one/11)%2!=0) {
                return  one+11;
            }else{
                return one+10;
            }
            break;
        default:
            break;
    }
    return -1;
}
- (void)event:(UITapGestureRecognizer *)gesture {
    CGPoint point = [gesture locationInView:self.view];
    float x = point.x;
    float y = point.y;
    int a,b;
    a = (y-20)/diameter;
    if ((a%2)!=0) {
        b = (x - diameter/2)/diameter;
    }else
        b = x/diameter;
    if (([circle[a*11+b] getcolor_num]==0)||([circle[a*11+b] getcolor_num]==2)) {
        
        count ++;
        [circle[a*11+b] setcolor_num:1];
        [circle[a*11+b] setNeedsDisplay];
        [self move];
        [circle[a*11+b] setcolor_num:1];
        [circle[a*11+b] setNeedsDisplay];
    }
}
-(void)initgame{
    count = 0;
    for (int i = 0 ; i<11; i++) {
        for (int j = 0 ; j<11; j++) {
            [circle[i*11+j] setcolor_num:0];
        }
    }
    cat = 60;
    [circle[cat] setcolor_num:2];
    //[circle[cat] setBackgroundColor:[[UIColor alloc]initWithPatternImage:[UIImage imageNamed:@"c01.png"]]];
    for (int i = 0; i<zacount;) {
        int k = arc4random()%121;
        if (k==60) {
            continue;
        }else{
            [circle[k] setcolor_num:1];
            i++;
        }
    }
    for (int i = 0 ; i<11; i++) {
        for (int j = 0 ; j<11; j++) {
            [circle[i*11+j] setNeedsDisplay];
        }
    }
    [label setText:@"红色代表猫，黄色代表障碍物，蓝色代表无障碍地带，每点击一次猫会移动，用最少步数将猫围住"];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
