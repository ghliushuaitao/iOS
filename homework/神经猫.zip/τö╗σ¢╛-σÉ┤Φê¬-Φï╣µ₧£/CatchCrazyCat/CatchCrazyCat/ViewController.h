//
//  ViewController.h
//  CatchCrazyCat
//
//  Created by WH on 15-4-27.
//  Copyright (c) 2015年 LiQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
