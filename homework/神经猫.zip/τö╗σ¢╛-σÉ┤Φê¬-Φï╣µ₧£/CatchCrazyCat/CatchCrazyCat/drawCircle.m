//
//  drawCircle.m
//  CatchCrazyCat
//
//  Created by WH on 15-4-27.
//  Copyright (c) 2015年 LiQiang. All rights reserved.
//

#import "drawCircle.h"

@implementation drawCircle

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        color[0] = [UIColor colorWithRed:0 green:16 blue:166 alpha:1];//初试颜色
        color[1] = [UIColor colorWithRed:0xee green:0xaa blue:0x00 alpha:1];//障碍物颜色
        color[2] = [UIColor colorWithRed:0xff green:0x00 blue:0x00 alpha:1];//猫的颜色
    }
    return self;
}
-(void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    //CGContextSetRGBStrokeColor(context, 33, 5, 0, 1.0);
    CGContextSetFillColorWithColor(context,color[color_num].CGColor);
    CGContextSetLineWidth(context, 1.0);
    CGContextAddEllipseInRect(context, CGRectMake(left, top, diameter, diameter));
    //CGContextDrawPath(context, kCGPathFillStroke);
    CGContextFillPath(context);
}
-(void)setcolor_num:(int)num{
    color_num = num;
}
-(int)getcolor_num{
    return color_num;
}
-(void)setdiameter:(int)leftm :(int)topm :(int)meter{
    left = leftm;
    top = topm;
    diameter = meter;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
