//
//  drawCircle.h
//  CatchCrazyCat
//
//  Created by WH on 15-4-27.
//  Copyright (c) 2015年 LiQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface drawCircle : UIView
{
    UIColor * color[3];
    int color_num;
    int diameter;
    int left;
    int top;
}
-(void)setcolor_num:(int)num;
-(void)setdiameter:(int)leftm :(int)topm :(int)meter;
-(int)getcolor_num;
@end
