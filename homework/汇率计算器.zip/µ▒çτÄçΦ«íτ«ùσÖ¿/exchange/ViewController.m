//
//  ViewController.m
//  exchange
//
//  Created by 王品学 on 15/4/23.
//  Copyright (c) 2015年 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    UITextField *input;
    UITextField *output;
    UILabel *label1;
    UILabel *label2;
    UILabel *label3;
    UILabel *label_RMB;
    UILabel *label_object;
    BOOL flag;
    int color;
    UIImage *btnImg;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    btnImg = [UIImage imageNamed:@"blue_128.png"];
    UIEdgeInsets insets = UIEdgeInsetsMake(0, 0, 0, 0);
    btnImg = [btnImg resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeTile];
    
    UIImageView *imageview=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon.png"]];
    [imageview setFrame:CGRectMake(15, 20, 70, 70)];
    [self.view addSubview:imageview];
    //设置view背景图片
    
    
    UIImage *image = [UIImage imageNamed:@"001.jpg"];
    self.view.layer.contents = (id) image.CGImage;    // 如果需要背景透明加上下面这句
    self.view.layer.backgroundColor = [UIColor clearColor].CGColor;
  
    flag=0;  //最先的时候没有交换币种
    //[self.view setBackgroundColor:[UIColor blackColor]];
    //设置label(货币兑换)
    label1=[[UILabel alloc]init];
    label1.font = [UIFont boldSystemFontOfSize:20];
    
    [label1 setFrame:CGRectMake(90, 20, 80, 30)];
    label1.text=@"货币兑换";
    [self.view addSubview:label1];
    
    //设置label(1人民币)
    label2=[[UILabel alloc]init];
    [label2 setFrame:CGRectMake(90, 50, 300, 25)];
    label2.text=@"1人民币元=0.1615美元";
    [self.view addSubview:label2];
    
    //设置label(1美元)
    label3=[[UILabel alloc]init];
    [label3 setFrame:CGRectMake(90, 70, 300, 25)];
    label3.text=@"1美元=6.1930人民币元";
    [self.view addSubview:label3];
    
    //设置label  RMB
    label_RMB=[[UILabel alloc]init];
    [label_RMB setFrame:CGRectMake(5, 0, 130, 35)];
    label_RMB.text=@"人民币RMB";
//    [self.view addSubview:label_RMB];
    
    //设置label(1美元)
    label_object=[[UILabel alloc]init];
    [label_object setFrame:CGRectMake(5, 0, 130, 35)];
    label_object.text=@"美元USD";
//    [self.view addSubview:label_object];
    
    //输入框输入 rmb的数值
    input =[[UITextField alloc]initWithFrame:CGRectMake(15, 95, 290, 35)];
    [input setBackgroundColor:[UIColor grayColor]];
    [input addSubview:label_RMB];
    [input setEnabled:false];
    input.textAlignment=2;
    [self.view addSubview:input];
    [input addSubview:label_RMB];
    
    //设置换主题的按钮
    //设置数组(输入的数字)
    NSArray *arr3=[[NSArray alloc]initWithObjects:@"1",@"2",@"3",nil];
    int z=0;
    
    // 利用循环排列，数字按钮
    for(int i=0;i<1;i++){
        for (int j=0; j<3; j++) {
            UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:[NSString stringWithFormat:@"%@",[arr3 objectAtIndex:z]] forState:UIControlStateNormal];
            z++;
            [btn setFrame:CGRectMake(220+j*30, 30, 20, 20)];
            [btn removeFromSuperview];
            [btn setBackgroundColor:[UIColor grayColor]];
            [btn addTarget:self action:@selector(click_orange:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
        }
        
    }

    
    //设置转换按钮
    UIButton *btn_change=[[UIButton alloc]initWithFrame:CGRectMake(100, 135, 100, 30)];
    [btn_change setTitle:@"EXCHANGE" forState:UIControlStateNormal];
    [btn_change setBackgroundImage:[UIImage imageNamed:@"exchange.png"]forState:UIControlStateNormal];
    [btn_change addTarget:self action:@selector(click_ex:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn_change];
    
//    UIButton *btn_orange=[[UIButton alloc]initWithFrame:CGRectMake(30, 135, 30, 30)];
//    [btn_orange setTitle:@"oeang" forState:UIControlStateNormal];
//    [btn_orange setBackgroundColor:[UIColor grayColor]];
//    [btn_orange addTarget:self action:@selector(click_orange) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn_orange];
    
    //输出框，目前是空的
    output =[[UITextField alloc]initWithFrame:CGRectMake(15, 170, 290, 35)];
    [output setBackgroundColor:[UIColor grayColor]];
    [output setEnabled:false];
    output.textAlignment=2;
    [self.view addSubview:output];
    [output addSubview:label_object];
    
    //设置数组(输入的数字)
    NSArray *arr=[[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"←",@"6",@"7",@"8",@"9",@"0",@".",nil];
    int x=0;
    
    // 利用循环排列，数字按钮
    for(int i=0;i<2;i++){
        for (int j=0; j<6; j++) {
            UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:[NSString stringWithFormat:@"%@",[arr objectAtIndex:x]] forState:UIControlStateNormal];
            x++;
            [btn setFrame:CGRectMake(15+j*50, 220+i*50, 40, 40)];
            [btn removeFromSuperview];
            [btn setBackgroundColor:[UIColor grayColor]];
            [btn addTarget:self action:@selector(click_num_in:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
        }
        
    }
    
    //设置数组
    NSArray *arr2=[[NSArray alloc]initWithObjects:@"清空",@"日元JPY",@"美元USD",@"欧元EUR",@"英镑GBP",@"韩元KER",@"港元HKD",@"澳元AUD",@"加元CAD",nil];
    int y=0;
    
    
    // 利用循环排列各国的名字，设置它们都分别为按钮
    for(int i=0;i<3;i++){
        for (int j=0; j<3; j++) {
            UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:[NSString stringWithFormat:@"%@",[arr2 objectAtIndex:y]] forState:UIControlStateNormal];
            y++;
            [btn setFrame:CGRectMake(15+j*100, 325+i*50, 90, 40)];
            [btn setBackgroundColor:[UIColor grayColor]];
            [btn addTarget:self action:@selector(click_money:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
            }
        
    }
    
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)click_num_in:(UIButton*)sender{
    if(flag==0){
    //判断是否为回退符号
    if([sender.titleLabel.text isEqualToString:@"←"]){
        //计算text输入框里的字符串数量
        int count;
        NSString *str=input.text;
        count=[str length];
        //截取从0到count－1的数
        if(count!=0){
            NSRange rang = NSMakeRange(0, count-1);
            NSString * strRang = [str substringWithRange:rang];
            input.text=[NSString stringWithFormat:@"%@",strRang];
            return;
        }
        return;
    }
    
    input.text =[NSString stringWithFormat:@"%@%@",input.text,sender.titleLabel.text];
    }
    else{
        //判断是否为回退符号
        if([sender.titleLabel.text isEqualToString:@"←"]){
            //计算text输入框里的字符串数量
            int count;
            NSString *str=output.text;
            count=[str length];
            //截取从0到count－1的数
            if(count!=0){
                NSRange rang = NSMakeRange(0, count-1);
                NSString * strRang = [str substringWithRange:rang];
                output.text=[NSString stringWithFormat:@"%@",strRang];
                return;
            }
            return;
        }
        output.text =[NSString stringWithFormat:@"%@%@",output.text,sender.titleLabel.text];
    }

}

//点击国家按钮，匹配对应的汇率，进行计算并输出在输出框
-(void)click_money:(UIButton*)sender{
    if([sender.titleLabel.text isEqualToString:@"清空"]){

        label2.text=@"1人民币元=1人民币元";
        label3.text=@"1人民币元=1人民币元";
        output.text=@"";
        input.text=@"";
      /*  if(flag==0){
        label_RMB.text=@"人民币RMB";
        label_object.text=@"美元USD";
            return;
        }
        else{
            label_object.text=@"人民币RMB";
            label_RMB.text=@"美元USD";
            return;
        }*/
        label_RMB.text=@"人民币RMB";
        label_object.text=@"美元USD";
        if (flag==1) {
            UITextField *text_temp=[[UITextField alloc]init];
            text_temp=input;
            input=output;
            output=text_temp;
            [input addSubview:label_RMB];
            [output addSubview:label_object];
        }
        
        flag=0;
    }
    
    if([sender.titleLabel.text isEqualToString:@"美元USD"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        
        label2.text=@"1人民币元=0.1615美元";
        label3.text=@"1美元=6.1930人民币元";
        
        if(flag==0){
        //将string类型的输入数，转化成float;
        float s = [input.text floatValue];
        output.text=[NSString stringWithFormat:@"%f",s*0.1615];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*6.193];
        }
//        return;
    }
    
    if([sender.titleLabel.text isEqualToString:@"日元JPY"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        label2.text=@"1人民币元=19.2104日元";
        label3.text=@"1日元=0.0521人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*19.2104];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*0.0521];
        }
    }
    
    if([sender.titleLabel.text isEqualToString:@"欧元EUR"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        label2.text=@"1人民币元=0.1484欧元";
        label3.text=@"1欧元=6.7367人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*0.1484];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*6.7367];
        }
    }

    if([sender.titleLabel.text isEqualToString:@"英镑GBP"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        
        label2.text=@"1人民币元=0.1063英镑";
        label3.text=@"1英镑=9.4047人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*0.1063];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*9.4047];
        }
    }
    
    if([sender.titleLabel.text isEqualToString:@"韩元KER"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        
        label2.text=@"1人民币元=173.6461韩元";
        label3.text=@"1韩元=0.0058人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*173.6461];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*0.0058];
        }
    }
    
    if([sender.titleLabel.text isEqualToString:@"港元HKD"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        
        label2.text=@"1人民币元=1.2514港元";
        label3.text=@"1港元=0.7991人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*1.2514];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*0.0058];
        }
    }
    
    if([sender.titleLabel.text isEqualToString:@"澳元AUD"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        
        label2.text=@"1人民币元=0.2067澳元";
        label3.text=@"1澳元=4.838人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*0.2067];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*4.838];
        }
    }
    
    if([sender.titleLabel.text isEqualToString:@"加元CAD"]){
        
        //将输入框里的label换掉
        label_object.text=[NSString stringWithFormat:@"%@",sender.titleLabel.text];
        
        label2.text=@"1人民币元=0.1966加元";
        label3.text=@"1加元=5.0871人民币元";
        if(flag==0){
            //将string类型的输入数，转化成float;
            float s = [input.text floatValue];
            output.text=[NSString stringWithFormat:@"%f",s*0.1966];
        }
        if(flag==1){
            //将string类型的输入数，转化成float;
            float s = [output.text floatValue];
            input.text=[NSString stringWithFormat:@"%f",s*5.0871];
        }
    }
}

//设置点击了 交换 两种币种按钮的方法
-(void)click_ex:(UIButton*)sender{
    //点击了  币种 的label交换
    if(flag==0) flag=1;
    else if (flag==1) flag=0;
//  UILabel *label_temp=[[UILabel alloc]init];
//   label_temp.text=label_RMB.text;
//   label_RMB.text=label_object.text;
//    label_object.text=label_temp.text;

//    label_temp=label_RMB;
//    label_RMB=label_object;
//    label_object=label_temp;
    input.text=@"";
    output.text=@"";
   //设置输入和输出框的交换
    UITextField *text_temp=[[UITextField alloc]init];
    text_temp=input;
    input=output;
    output=text_temp;
    [input addSubview:label_RMB];
    [output addSubview:label_object];
}
-(void)click_orange:(UIButton*)sender{
    if([sender.titleLabel.text isEqualToString:@"1"]) {color=1;}
     else if([sender.titleLabel.text isEqualToString:@"2"]) color=2;
     else if([sender.titleLabel.text isEqualToString:@"3"]) {color=3;}
    
    [input removeFromSuperview];
    switch (color) {
        case 1:
            input.layer.contents = (id) btnImg.CGImage;    // 如果需要背景透明加上下面这句
            input.layer.backgroundColor = [UIColor clearColor].CGColor;
            //[input setBackground:[UIImage imageNamed:@"btn_blue1"]];
            break;
        case 2:
            [input setBackground:[UIImage imageNamed:@"btn_orange"]];
            break;
        case 3:
            [input setBackgroundColor:[UIColor grayColor]];
            break;
        default:
            [input setBackgroundColor:[UIColor grayColor]];
            break;
    }
    [self.view addSubview:input];

    
    [output removeFromSuperview];
    //输出框换颜色
    switch (color) {
        case 1:
            output.layer.contents = (id) btnImg.CGImage;    // 如果需要背景透明加上下面这句
            output.layer.backgroundColor = [UIColor clearColor].CGColor;
            //[output setBackgroundColor:[UIColor blueColor]];
            break;
        case 2:
            [output setBackground:[UIImage imageNamed:@"btn_orange"]];
            break;
        case 3:
            [output setBackgroundColor:[UIColor grayColor]];
            break;
        default:
            [output setBackgroundColor:[UIColor grayColor]];
            break;
    }
  
    [self.view addSubview:output];

    
    //设置数组(输入的数字)
    NSArray *arr=[[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"←",@"6",@"7",@"8",@"9",@"0",@".",nil];
    int x=0;

    // 利用循环排列，数字按钮
    for(int i=0;i<2;i++){
        for (int j=0; j<6; j++) {
            UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:[NSString stringWithFormat:@"%@",[arr objectAtIndex:x]] forState:UIControlStateNormal];
            x++;
            [btn setFrame:CGRectMake(15+j*50, 220+i*50, 40, 40)];
            [btn removeFromSuperview];
            switch (color) {
                case 1:
                    btn.layer.contents = (id) btnImg.CGImage;    // 如果需要背景透明加上下面这句
                    btn.layer.backgroundColor = [UIColor clearColor].CGColor;

                    break;
                case 2:
                    [btn setBackgroundImage:[UIImage imageNamed:@"btn_orange.png"] forState:UIControlStateNormal];
                    break;
                case 3:
                    [btn setBackgroundColor:[UIColor grayColor]];
                    break;
                default:
                    [btn setBackgroundColor:[UIColor grayColor]];
                    break;
            }
            [btn addTarget:self action:@selector(click_num_in:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
        }
    }
    
    //设置数组
    NSArray *arr2=[[NSArray alloc]initWithObjects:@"清空",@"日元JPY",@"美元USD",@"欧元EUR",@"英镑GBP",@"韩元KER",@"港元HKD",@"澳元AUD",@"加元CAD",nil];
    int y=0;
    
    
    // 利用循环排列各国的名字，设置它们都分别为按钮
    for(int i=0;i<3;i++){
        for (int j=0; j<3; j++) {
            UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:[NSString stringWithFormat:@"%@",[arr2 objectAtIndex:y]] forState:UIControlStateNormal];
            y++;
            [btn setFrame:CGRectMake(15+j*100, 325+i*50, 90, 40)];
            switch (color) {
                case 1:
                    btn.layer.contents = (id) btnImg.CGImage;    // 如果需要背景透明加上下面这句
                    btn.layer.backgroundColor = [UIColor clearColor].CGColor;
                    break;
                case 2:
                    [btn setBackgroundImage:[UIImage imageNamed:@"btn_orange.png"] forState:UIControlStateNormal];
                    break;
                case 3:
                    [btn setBackgroundColor:[UIColor grayColor]];
                    break;
                default:
                    [btn setBackgroundColor:[UIColor grayColor]];
                    break;
            }
            [btn addTarget:self action:@selector(click_money:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
        }
        
    }


}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
