//
//  snowDemoTests.m
//  snowDemoTests
//
//  Created by a a a a a on 12-1-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "snowDemoTests.h"

@implementation snowDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in snowDemoTests");
}

@end
