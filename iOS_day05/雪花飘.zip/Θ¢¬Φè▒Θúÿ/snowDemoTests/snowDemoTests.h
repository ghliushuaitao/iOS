//
//  snowDemoTests.h
//  snowDemoTests
//
//  Created by a a a a a on 12-1-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface snowDemoTests : SenTestCase

@end
