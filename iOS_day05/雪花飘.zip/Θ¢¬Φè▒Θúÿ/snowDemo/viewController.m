//
//  viewController.m
//  snowDemo
//
//  Created by a a a a a on 12-1-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "viewController.h"
#define MAX_SIZE 25
#define MIN_TIME 5
#define MAX_TIME 20
@implementation viewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor colorWithRed:0.5 green:0.5 blue:1 alpha:1];
    
    [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
}
-(void)onTimer{
    UIImageView *snowView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"snow.png"]];
    
    [self.view addSubview:snowView];
    [snowView release];
 //............satrt   
    int startX=arc4random()%320;
    int endX=arc4random()%320;
    int sonwWidth=arc4random()%MAX_SIZE;
    int time=(arc4random()%(MAX_TIME-MIN_TIME))+MIN_TIME;
    snowView.frame=CGRectMake(endX, 460, sonwWidth, sonwWidth);

    snowView.alpha=0.25;
    
      
//..............end
    [UIView beginAnimations:nil context:snowView];
    [UIView setAnimationDuration:time];
    snowView.frame=CGRectMake(startX, -1*MAX_SIZE, sonwWidth, sonwWidth);
    [UIView commitAnimations];
    [NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(releaseView:) userInfo:snowView repeats:NO];    

}
-(void)releaseView:(NSTimer*)time{
    UIImageView *imageView=[time userInfo];
    [imageView removeFromSuperview];

}
@end
