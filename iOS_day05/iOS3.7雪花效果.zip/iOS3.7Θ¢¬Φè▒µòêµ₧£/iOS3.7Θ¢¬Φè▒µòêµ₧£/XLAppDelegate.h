//
//  XLAppDelegate.h
//  iOS3.7雪花效果
//
//  Created by MS on 15-5-6.
//  Copyright (c) 2015年 xuli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
