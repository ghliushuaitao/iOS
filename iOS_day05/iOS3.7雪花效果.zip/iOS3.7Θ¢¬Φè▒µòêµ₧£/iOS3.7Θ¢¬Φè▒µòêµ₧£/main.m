//
//  main.m
//  iOS3.7雪花效果
//
//  Created by MS on 15-5-6.
//  Copyright (c) 2015年 xuli. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XLAppDelegate class]));
    }
}
