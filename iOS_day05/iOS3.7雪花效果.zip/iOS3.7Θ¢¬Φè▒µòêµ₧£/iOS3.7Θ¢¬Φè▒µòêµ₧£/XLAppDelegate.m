//
//  XLAppDelegate.m
//  iOS3.7雪花效果
//
//  Created by MS on 15-5-6.
//  Copyright (c) 2015年 xuli. All rights reserved.
//

#import "XLAppDelegate.h"

#define snowWidth (arc4random()%20 + 10)//设置雪花的宽度
#define snowX (arc4random()%(int)self.window.frame.size.width)//设置雪花的出现位置

@interface XLAppDelegate ()
{
    NSMutableArray * arr;//存放雪花图片视图对象
    //物理动画
    UIDynamicAnimator*ani;
    //现实行为 摩擦力 阻力
    UIDynamicItemBehavior*dynamic;
    //重力行为
    UICollisionBehavior*collision;
    //弹力行为
    UIGravityBehavior*gravity;
    
}
@end

@implementation XLAppDelegate
-(void)dealloc
{
    [arr release];
    [self.window release];
    [super dealloc];
}
-(void)createImageView
{
    ani=[[UIDynamicAnimator alloc]initWithReferenceView:self.window];
    //创建实例化
    dynamic=[[UIDynamicItemBehavior alloc]initWithItems:nil];
    dynamic.elasticity=1;
    collision=[[UICollisionBehavior alloc]initWithItems:nil];
    //设置边界
    collision.translatesReferenceBoundsIntoBoundary=YES;
    gravity=[[UIGravityBehavior alloc]initWithItems:nil];
//    gravity.gravityDirection=CGVectorMake(0.5, -0.5);
    
    [ani addBehavior:dynamic];
    [ani addBehavior:collision];
    [ani addBehavior:gravity];

//    arr = [[NSMutableArray alloc]init];
//    for(int i = 0;i < 20;i++)
//    {
//        UIImageView * imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"snow.png"]];
//        float width = snowWidth;//获取雪花的宽度
//        imageView.frame = CGRectMake(snowX, -30, width, width);
//        //设置雪花的透明度
//        float alpha = (float)(arc4random()%10)/10;
//        imageView.alpha = alpha;
//        //把imageView添加到窗口视图上
//        [self.window addSubview:imageView];
//    
//        [gravity addItem:imageView];
//        [collision addItem:imageView];
//        [dynamic addItem:imageView];
//        
//        //把imageView添加到数组中
//        [arr addObject:imageView];
//        [imageView release];
//    }
//
//    //间隔一定时间出现一朵雪花并且落下
//    [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(makeSnow) userInfo:nil repeats:YES];
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UIImageView*imageView=[[UIImageView alloc]initWithFrame:CGRectMake(arc4random()%320+1, arc4random()%100+1, 50, 50)];
    imageView.image=[UIImage imageNamed:@"snow"];
    [self.window addSubview:imageView];
    [gravity addItem:imageView];
    [collision addItem:imageView];
    [dynamic addItem:imageView];
    


}
-(void)makeSnow
{
    //为每多雪花添加tag值 为了调用UIView动画效果协议中的方法使用
    static int flag = 0;
    if(arr.count > 0)
    {
        UIImageView * imageView = [arr objectAtIndex:0];
        imageView.tag = ++flag;

        [arr removeObjectAtIndex:0];
    }
}
-(void)snowDown:(UIImageView *)imageView
{
    //雪花下落的动画效果
    //1、开始动画
    [UIView beginAnimations:[NSString stringWithFormat:@"%d",(int)imageView.tag] context:nil];
    //设置雪花落地的时间
    [UIView setAnimationDuration:6];
    //设置雪花落地 无风情况下 垂直落地
    imageView.frame = CGRectMake(imageView.frame.origin.x, self.window.frame.size.height, imageView.frame.size.width, imageView.frame.size.height);
    //2、设置的是动画的代理
    [UIView setAnimationDelegate:self];
    //3、调用协议中的方法
    [UIView setAnimationDidStopSelector:@selector(snowStop:)];
    //4、关闭动画
    [UIView commitAnimations];
}
-(void)snowStop:(NSString *)animationID
{
    //animationID是图片视图的tag值
    UIImageView * imageSnow = (UIImageView *)[self.window viewWithTag:[animationID intValue]];
    float width = snowWidth;
    imageSnow.frame = CGRectMake(snowX, -30, width, width);
    [arr addObject:imageSnow];
}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor cyanColor];
    
    [self createImageView];
    
    [self.window makeKeyAndVisible];
    [self.window release];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
