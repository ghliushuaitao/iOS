//
//  AppDelegate.h
//  JsonTest
//
//  Created by Dn on 13-4-11.
//  Copyright (c) 2013年 Dn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
