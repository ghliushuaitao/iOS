//
//  StartViewController.m
//  Jiyidachuangguan
//
//  Created by teacher on 15-4-21.
//  Copyright (c) 2015年 nbut. All rights reserved.
//

#import "StartViewController.h"
#import "GameViewController.h"

@interface StartViewController ()

@end

@implementation StartViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createUI];
    [self createUIImageView];
    [self createButton];
    
}

-(void)createUI
{
//    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
//    [button setTitle:@"来吧，开始挑战我吧！" forState:UIButtonTypeSystem];
    self.view.backgroundColor = [UIColor grayColor];
}

-(void)createUIImageView
{
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 500)];
    imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"start2.jpeg"]];
    [self.view addSubview:imageView];

}

-(void)createButton
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(80, 400, 160, 40);
    [button setTitle:@"少侠，可敢来应战！" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor whiteColor];
    button.tag =100;
    [button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
}

-(void)onButtonClick:(UIButton *)sender
{
    if (100 ==sender.tag)
    {
        GameViewController *gameVC = [[GameViewController alloc]init];
        [self presentViewController:gameVC animated:YES completion:^{}];
    }
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
