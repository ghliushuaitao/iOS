//
//  GameViewController3.m
//  Jiyidachuangguan
//
//  Created by teacher on 15-4-21.
//  Copyright (c) 2015年 nbut. All rights reserved.
//

#import "GameViewController3.h"
#import "TiShiViewController.h"
#import "StartViewController.h"

@interface GameViewController3 ()

@end

@implementation GameViewController3
{
    UILabel *_label;
    NSTimer *_timer;
    NSInteger _value;
    UIButton* _button;
    int photoNum;
    int mubiaoNum;
    TiShiViewController *_tishiVC;
    //UIView *tishiView;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self configUI];
    [self createTimer];
    [self createLabel];
    
}


/*
 配置本VC的UI
 */
-(void)configUI
{
    
    for(NSInteger col = 0;col <3;++col )
    {
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(10+col*100, 80, 100, 100);
        _button.tag=col+1;
        //UIimage：是表示（内存中的）图片的类
        //imageNamed：是加载图片并创建UIimage类对象的方法
        NSString *imageName = [NSString stringWithFormat:@"3_%ld.jpg",col+1];
        UIImage *image = [UIImage imageNamed:imageName];
        [_button setImage:image forState:UIControlStateNormal];
        // [_button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_button];
    }
    
    for(NSInteger col = 0;col <3;++col )
    {
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(10+col*100, 180, 100, 100);
        _button.tag=col+4;
        //UIimage：是表示（内存中的）图片的类
        //imageNamed：是加载图片并创建UIimage类对象的方法
        NSString *imageName = [NSString stringWithFormat:@"3_%ld.jpg",col+4];
        UIImage *image = [UIImage imageNamed:imageName];
        [_button setImage:image forState:UIControlStateNormal];
        //[_button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_button];
    }
    
    for(NSInteger col = 0;col <3;++col )
    {
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(10+col*100, 280, 100, 100);
        _button.tag=col+7;
        //UIimage：是表示（内存中的）图片的类
        //imageNamed：是加载图片并创建UIimage类对象的方法
        NSString *imageName = [NSString stringWithFormat:@"3_%ld.jpg",col+7];
        UIImage *image = [UIImage imageNamed:imageName];
        [_button setImage:image forState:UIControlStateNormal];
        //[_button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_button];
    }
}



/*
 计时完毕，按钮点击事件处理
 */
-(void)onButtonClick:(UIButton*)sender
{
    photoNum = sender.tag;
    NSLog(@"button.tag:%d",photoNum);
    if (photoNum == mubiaoNum)
    {
        NSLog(@"成功");
        _tishiVC = [[TiShiViewController alloc]init];
        _tishiVC.view.frame = CGRectMake(60, 140, 200, 180);
        _tishiVC.view.backgroundColor = [UIColor whiteColor];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 40, 200, 20)];
        [label setText:@"少侠真心牛逼"];
        [label setTextAlignment:NSTextAlignmentCenter];
        label.textAlignment =NSTextAlignmentCenter;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(55, 120, 80, 20);
        button.backgroundColor = [UIColor whiteColor];
        button.tag = 200;
        [button setTitle:@"你已无敌" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(onButtonClickNext:) forControlEvents:UIControlEventTouchUpInside];
        
        [_tishiVC.view addSubview:button];
        [_tishiVC.view addSubview:label];
        [self.view addSubview:_tishiVC.view];
        
       
    }
    else
    {
        NSLog(@"失败");
        _tishiVC = [[TiShiViewController alloc]init];
        _tishiVC.view.frame = CGRectMake(60, 140, 200, 180);
        _tishiVC.view.backgroundColor = [UIColor whiteColor];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 40, 200, 20)];
        [label setText:@"少侠闯关失败"];
        label.textAlignment =NSTextAlignmentCenter;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(55, 120, 80, 20);
        button.backgroundColor = [UIColor whiteColor];
        button.tag = 201;
        [button setTitle:@"不要灰心" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(onButtonClickNext:) forControlEvents:UIControlEventTouchUpInside];
        
        [_tishiVC.view addSubview:button];
        [_tishiVC.view addSubview:label];
        [self.view addSubview:_tishiVC.view];
        
        
        
        //[self dismissViewControllerAnimated:YES completion:nil];
        //[self presentViewController:self animated:YES completion:^{}];
        //[self.navigationController popToRootViewControllerAnimated:YES];
    }
}
-(void)onButtonClickNext:(UIButton *)sender
{
    if (sender.tag == 200)
    {
//        GameViewController3 *gameVC3 = [[GameViewController3 alloc]init];
//        [self presentViewController:gameVC3 animated:YES completion:^{}];
        StartViewController *startVC = [[StartViewController alloc]init];
        [self presentViewController:startVC animated:YES completion:^{}];
    }
    else
    {
        //[self dismissViewControllerAnimated:YES completion:nil];
        StartViewController *startVC = [[StartViewController alloc]init];
        [self presentViewController:startVC animated:YES completion:^{}];
        
    }
    
}



/*
 创建定时器
 */
-(void)createTimer
{
    //定时值
    _value  = 10;
    _timer  = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onTime) userInfo:nil repeats:YES];
}
-(void)onTime
{
    if (_value > 0)
    {
        _value = _value - 1;
        _label.text =[NSString stringWithFormat:@"%ld",(long)_value];
    }
    else
    {
        [_timer invalidate];
        
        //图片隐藏
        for(NSInteger col = 0;col <3;++col )
        {
            _button = [UIButton buttonWithType:UIButtonTypeCustom];
            _button.frame = CGRectMake(10+col*100, 80, 100, 100);
            _button.tag=col+1;
            //UIimage：是表示（内存中的）图片的类
            //imageNamed：是加载图片并创建UIimage类对象的方法
            NSString *imageName = [NSString stringWithFormat:@"cai.png"];
            UIImage *image = [UIImage imageNamed:imageName];
            [_button setImage:image forState:UIControlStateNormal];
            [_button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:_button];
        }
        
        for(NSInteger col = 0;col <3;++col )
        {
            _button = [UIButton buttonWithType:UIButtonTypeCustom];
            _button.frame = CGRectMake(10+col*100, 180, 100, 100);
            _button.tag=col+4;
            //UIimage：是表示（内存中的）图片的类
            //imageNamed：是加载图片并创建UIimage类对象的方法
            NSString *imageName = [NSString stringWithFormat:@"cai.png"];
            UIImage *image = [UIImage imageNamed:imageName];
            [_button setImage:image forState:UIControlStateNormal];
            [_button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:_button];
        }
        
        for(NSInteger col = 0;col <3;++col )
        {
            _button = [UIButton buttonWithType:UIButtonTypeCustom];
            _button.frame = CGRectMake(10+col*100, 280, 100, 100);
            _button.tag=col+7;
            //UIimage：是表示（内存中的）图片的类
            //imageNamed：是加载图片并创建UIimage类对象的方法
            NSString *imageName = [NSString stringWithFormat:@"cai.png"];
            UIImage *image = [UIImage imageNamed:imageName];
            [_button setImage:image forState:UIControlStateNormal];
            [_button addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:_button];
        }
        
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(121,390 , 80 , 80)];//生成目标图片窗口大小
        //获取1到9之间的整数的代码如下:
        mubiaoNum = (arc4random() % 9) + 1;
        
        NSString *imageName = [NSString stringWithFormat:@"3_%d.jpg",mubiaoNum];
        imageView.image = [UIImage imageNamed:imageName];
        
        [self.view addSubview:imageView];
        
    }
}


/*
 用于显示倒计时数字
 */
-(void)createLabel
{
    _label = [[UILabel alloc]initWithFrame:CGRectMake(118, 20, 80,60 )];
    _label.backgroundColor = [UIColor grayColor];
    _label.font = [UIFont systemFontOfSize:50];
    _label.text =@"10";
    _label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_label];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
