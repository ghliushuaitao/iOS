//
//  QFlmageView.m
//  Jiyidachuangguan
//
//  Created by teacher on 15-4-21.
//  Copyright (c) 2015年 nbut. All rights reserved.
//

#import "QFlmageView.h"

@implementation QFlmageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
